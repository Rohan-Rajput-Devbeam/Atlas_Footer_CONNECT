declare const styles: {
    footer: string;
    footerContent: string;
    row: string;
    needhelp: string;
    spanhelp: string;
    footerVerbiage: string;
    averbiage: string;
    footerlinks: string;
    copyrightRow: string;
    div: string;
    a1: string;
};
export default styles;
//# sourceMappingURL=FooterWebPart.module.scss.d.ts.map