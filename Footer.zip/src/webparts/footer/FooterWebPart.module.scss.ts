/* tslint:disable */
require("./FooterWebPart.module.css");
const styles = {
  footer: 'footer_b3828ed5',
  footerContent: 'footerContent_b3828ed5',
  row: 'row_b3828ed5',
  needhelp: 'needhelp_b3828ed5',
  spanhelp: 'spanhelp_b3828ed5',
  footerVerbiage: 'footerVerbiage_b3828ed5',
  averbiage: 'averbiage_b3828ed5',
  footerlinks: 'footerlinks_b3828ed5',
  copyrightRow: 'copyrightRow_b3828ed5',
  div: 'div_b3828ed5',
  a1: 'a1_b3828ed5'
};

export default styles;
/* tslint:enable */